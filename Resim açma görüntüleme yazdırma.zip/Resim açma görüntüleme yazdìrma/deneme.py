# Kaynak :    https://www.youtube.com/watch?v=IAVjMKTyQg4&list=PLzcys7whQ6eSJdSHJh-xdOLvWPP24J76x&index=2




import cv2
import numpy as np

resim = cv2.imread("Logo.png",0)

cv2.imshow("Logo Baslik",resim)

cv2.imwrite("yeniresim.png",resim)

cv2.waitKey(0)
cv2.destroyAllWindows()
